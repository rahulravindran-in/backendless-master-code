<?php

# Added By Rahul Ravindran @ 02:40 AM 12-10-2019

namespace OAuth2;
use OAuth2\Storage\ScopeInterface;

// configure your available scopes
$defaultScope = 'basic';
$supportedScopes = array(
  'basic',
  'postonwall',
  'accessphonenumber'
);
$memory = new OAuth2\Storage\Memory(array(
  'default_scope' => $defaultScope,
  'supported_scopes' => $supportedScopes
));
$scopeUtil = new OAuth2\Scope($memory);

$server->setScopeUtil($scopeUtil);

?>
